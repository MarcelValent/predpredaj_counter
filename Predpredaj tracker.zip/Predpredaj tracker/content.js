(async () => {
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
  await delay(1000);

  const firstBtn = document.querySelector('button.place_select[data-href*="/get-sector-data/"]');

  const dataHref = firstBtn.getAttribute("data-href");
  const EVENT_ID = dataHref?.split("/")[3];
  if (!EVENT_ID) return console.error("Event ID not found.");

  const sectorElements = [...document.querySelectorAll('li.list-group-item[data-sector-id]')];
  const SECTOR_IDS = sectorElements.map(el => el.getAttribute('data-sector-id')).filter(Boolean);

  const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content ||
    document.cookie.match(/csrftoken=([^;]+)/)?.[1];

  let totalSold = 0;
  let totalAvailable = 0;

  for (const sectorId of SECTOR_IDS) {
    const url = `https://predpredaj.zoznam.sk/sk/get-sector-data/${EVENT_ID}/${sectorId}/`;

    try {
      const response = await fetch(url, {
        method: "GET",
        headers: {
          "Accept": "*/*",
          "X-Requested-With": "XMLHttpRequest",
          "X-CSRFToken": csrfToken,
        },
        credentials: "include"
      });

      const rawJson = await response.json();
      //console.log(`📦 JSON response for sector ${sectorId}:`, rawJson);

      const html = rawJson.html;
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");

      const allSeats = doc.querySelectorAll('.addtocart_track');
      let available = 0;
      let sold = 0;

      allSeats.forEach(el => {
        const cls = el.className;
        if (cls.includes('available') && cls.includes('active_seat_item')) {
          available++;
        } else if (cls.includes('disabled')) {
          sold++;
        }
      });

      const total = sold + available;
      totalSold += sold;
      totalAvailable += available;

      console.log(`✅ Sector ${sectorId} — Sold: ${sold}, Available: ${available}, Total: ${total}`);
    } catch (err) {
      console.error(`❌ Error fetching sector ${sectorId}:`, err);
    }
  }

  alert(`🎫 TOTALS:\nSold: ${totalSold}\nAvailable: ${totalAvailable}\nTotal: ${totalSold + totalAvailable}`);
})();
