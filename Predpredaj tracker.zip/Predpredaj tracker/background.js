// No background tasks required
